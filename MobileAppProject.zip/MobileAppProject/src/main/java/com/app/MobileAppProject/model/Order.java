//package com.app.MobileAppProject.model;
//
//import jakarta.persistence.*;
//import lombok.Data;
//
//import java.util.HashSet;
//import java.util.Set;
//
////@Entity
////@Data
//public class Order {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    @Column(name = "order_Id")
//    private int id;
//
//
////    @ManyToOne(fetch = FetchType.LAZY)
////    @JoinColumn(name = "customer_Id", referencedColumnName = "customer_Id")
////    private Customer customer;
//
//
////    @ManyToOne(fetch = FetchType.LAZY)
////    @JoinColumn(name = "product_Id", referencedColumnName = "product_Id")
////    private Product product;
//
//}
