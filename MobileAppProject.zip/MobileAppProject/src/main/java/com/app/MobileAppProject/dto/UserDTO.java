package com.app.MobileAppProject.dto;

import lombok.Data;

@Data
public class UserDTO {
    private int id;
    private String firstname;
    private String lastname;
    private String email;
    private String password;

}
