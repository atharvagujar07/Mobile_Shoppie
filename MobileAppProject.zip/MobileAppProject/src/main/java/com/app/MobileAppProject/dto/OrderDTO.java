package com.app.MobileAppProject.dto;

public class OrderDTO {
//    private int id;
//    private long product_Id;
//
//    private int customer_Id;
}
