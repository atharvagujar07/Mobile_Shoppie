package com.app.MobileAppProject.reposistory;

import com.app.MobileAppProject.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleReposistory extends JpaRepository<Role,Integer> {
}
